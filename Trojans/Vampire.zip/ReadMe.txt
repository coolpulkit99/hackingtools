
                        ************************
                        *      Vampire v1.0    *
                        ************************
Disclaimer:
Vampire v1.0 is for educational purposes only...It can be used for malicious purposes but if you get caught using it in that kind of way dont try and lay any of it back on the author of this program..
So in short you get busted using this stupidly..It's your problem..
I wish cocknuts didnt sue and do stupid shit in this world like this so no one would have to right fucking STUPID disclaimers like this....


Package:
Vampire.exe - The Client
Server.exe - Non Registry Writing Server
Regserver.exe - Registry Writing Server

How to use:

Registry Writing Server:
To install the Registry writing server send them the regserver.exe.....This one will write to the registry so everytime the machine restarts the server restarts with it....

Non Registry Writing Server:
Simple send them the file Server.exe and that's it..This server will only run once and once you disconnect from the victim it will close also....So you cannot reconnect....When the victim restarts their machine it will no restart with it.....

Bugs/Known Problems:
There is none as yet.....If you find any contact me...My contact is on the bottom....

BIG THANKS TO:
Killboy - You fucking rock my thanx a LOT...
^_ChilL_^ - hehehe
Viulent J - For some reason i cant think of right now

Contact:
ICQ#: 31050340

Copyright � 1999 Ju1c3
